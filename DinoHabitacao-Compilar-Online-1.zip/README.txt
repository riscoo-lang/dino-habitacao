DINO HABITACAO - compilacao online

Para compilar:
1. Carregue todo o conteúdo deste projeto para a raiz do repositório GitHub.
2. Inclua a pasta .github/workflows/android.yml.
3. Abra Actions e execute "Build Dino Habitacao APK".
4. Quando terminar, descarregue o artifact "Dino-Habitacao-APK".
5. Extraia o ZIP do artifact e instale app-debug.apk.

Nota: o projeto abre como aplicação Android normal em ecrã inteiro horizontal.
A execução no ecrã traseiro depende do suporte do modelo/HyperOS Xiaomi e não foi testada.
